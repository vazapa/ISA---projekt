/*
* Name: Vaclav Zapletal
* Login: xzaple40
*/
#ifndef UTILS_H
#define UTILS_H
#include <stdio.h>    
#include <string.h>   
#include <stdint.h>   

#define KILO 1000
#define MEGA 1000000
#define GIGA 1000000000

#endif 